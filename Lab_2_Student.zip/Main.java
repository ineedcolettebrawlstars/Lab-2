import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private Course[] courses;
    private Scanner scanner;

    public Main() {
        courses = new Course[3];
        courses[0] = new Course("English", 20);
        courses[1] = new Course("Math 103", 20);
        courses[2] = new Course("Art 101", 20);
        scanner = new Scanner(System.in);
    }

    public void registerStudent() {
        System.out.println("\nAvailable courses:");
        for (int i = 0; i < courses.length; i++) {
            System.out.println((i + 1) + ". " + courses[i].getCourseName());
        }
        System.out.print("Enter course number (1-3): ");
        int courseNum = scanner.nextInt();
        scanner.nextLine(); 

        if (courseNum >= 1 && courseNum <= 3) {
            System.out.print("Enter student name: ");
            String studentName = scanner.nextLine();
            courses[courseNum - 1].registerStud(studentName);
        } else {
            System.out.println("Invalid course number.");
        }
    }

    public void dropClass() {
        System.out.println("\nAvailable courses:");
        for (int i = 0; i < courses.length; i++) {
            System.out.println((i + 1) + ". " + courses[i].getCourseName());
        }
        System.out.print("Enter course number (1-3): ");
        int courseNum = scanner.nextInt();
        scanner.nextLine(); 

        if (courseNum >= 1 && courseNum <= 3) {
            System.out.print("Enter student name: ");
            String studentName = scanner.nextLine();
            courses[courseNum - 1].dropStudent(studentName);
        } else {
            System.out.println("Invalid course number.");
        }
    }

    public void viewCourseDetails() {
        System.out.println("\nCourse Details:");
        for (Course course : courses) {
            System.out.println("\n-------------------");
            course.displayCourseDetails();
        }
    }

    public void runMenu() {
        boolean finished = false;
        while (!finished) {
            System.out.println("\n=== Course Registration System ===");
            System.out.println("1. Register for a course");
            System.out.println("2. Drop a course");
            System.out.println("3. View course details");
            System.out.println("4. Exit");
            System.out.print("Choose an option (1-4): ");
            
            int option = scanner.nextInt();
            scanner.nextLine(); 

            switch (option) {
                case 1:
                    registerStudent();
                    break;
                case 2:
                    dropClass();
                    break;
                case 3:
                    viewCourseDetails();
                    break;
                case 4:
                    finished = true;
                    System.out.println("Thanks for using the program.");
                    break;
                default:
                    System.out.println("Invalid entry. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        Main registration = new Main();
        registration.runMenu();
    }
}

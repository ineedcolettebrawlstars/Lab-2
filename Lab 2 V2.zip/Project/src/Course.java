import java.util.ArrayList;

public class Course {
    private String courseName;
    private int maxSeats;
    private ArrayList<String> registeredStudents;
    // Attributes

    // Constructor
    public Course(String courseName, int maxSeats) {
        this.courseName = courseName;
        this.maxSeats = maxSeats;
        this.registeredStudents = new ArrayList<>();
    }
    
   //Call for courseName
    public String getCourseName() {
        return courseName;
    }
    //Register a student with checks to ensure it doesn't surpass class size
    public boolean registerStudent(String studentName) {
        if (registeredStudents.size() < maxSeats) {
            registeredStudents.add(studentName);
            System.out.println(studentName + " has been registered for " + courseName + ".");
            return true;
        } else {
            System.out.println("Cannot register " + studentName + ". No available seats in " + courseName + ".");
            return false;
        }
    }

    // Dropping a student
    public boolean dropStudent(String studentName) {
        if (registeredStudents.remove(studentName)) {
            System.out.println(studentName + " has been dropped from " + courseName + ".");
            return true;
        } else {
            System.out.println(studentName + " is not registered in " + courseName + ".");
            return false;
        }
    }

    // Displaying the course
    public void displayCourseDetails() {
        System.out.println("Course Name: " + courseName);
        System.out.println("Max Seats: " + maxSeats);
        System.out.println("Registered Students (" + registeredStudents.size() + "): " + registeredStudents);
    }
}

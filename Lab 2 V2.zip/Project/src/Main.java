import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Pre-existing class array 
        ArrayList<Course> courses = new ArrayList<>();
        courses.add(new Course("English", 20));
        courses.add(new Course("Math 103", 20));
        courses.add(new Course("Art 101", 20));

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            // Menu display
            System.out.println("=== Student Course Registration System ===");
            System.out.println("1. Register for a course");
            System.out.println("2. Drop a course");
            System.out.println("3. View course details");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) { //Register for course
                System.out.println("Available Courses:");
                for (int i = 0; i < courses.size(); i++) {
                    System.out.println((i + 1) + courses.get(i).getCourseName());
                }
                System.out.print("Enter the course number you want to register for: ");
                int courseNumber = scanner.nextInt();
                scanner.nextLine();
                if (courseNumber < 1 || courseNumber > courses.size()) {
                    System.out.println("Invalid course number.");
                } else {
                    Course selectedCourse = courses.get(courseNumber - 1);
                    System.out.print("Enter your name: ");
                    String studentName = scanner.nextLine();
                    selectedCourse.registerStudent(studentName);
                }
            } else if (choice == 2) { //Drop a course
                System.out.println("Available Courses:");
                for (int i = 0; i < courses.size(); i++) {
                    System.out.println((i + 1) + courses.get(i).getCourseName());
                }
                System.out.print("Enter the course number you want to drop: ");
                int courseNumber = scanner.nextInt();
                scanner.nextLine();
                if (courseNumber < 1 || courseNumber > courses.size()) { //Making sure an error can't occur
                    System.out.println("Invalid course number.");
                } else {
                    Course selectedCourse = courses.get(courseNumber - 1);
                    System.out.print("Enter your name: ");
                    String studentName = scanner.nextLine();
                    selectedCourse.dropStudent(studentName); //Actually removing the student
                }
            } else if (choice == 3) {
                // View course details
                System.out.println("Available Courses:");
                for (int i = 0; i < courses.size(); i++) {
                    System.out.println((i + 1) + courses.get(i).getCourseName());
                }
            } else if (choice == 4) {
                // Close program!
                System.out.println("Thank you for using our program today.");
                running = false;
            } else {
                System.out.println("Invalid entry. Please try again.");
            }
            
        }
    }
}
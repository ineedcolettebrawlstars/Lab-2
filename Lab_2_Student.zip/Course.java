import java.util.ArrayList;

public class Course {
    private String courseName;
    private int maxSeats;
    private ArrayList<String> registeredStudents;

    public Course(String courseName, int maxSeats) {
        this.courseName = courseName;
        this.maxSeats = maxSeats;
        this.registeredStudents = new ArrayList<>();
    }

    public boolean registerStud(String studentName) {
        if (registeredStudents.size() < maxSeats) {
            registeredStudents.add(studentName);
            System.out.println(studentName + " has been registered for " + courseName + ".");
            return true;
        } else {
            System.out.println("Cannot register " + studentName + ". No available seats in " + courseName + ".");
            return false;
        }
    }

    public boolean dropStudent(String studentName) {
        if (registeredStudents.remove(studentName)) {
            System.out.println(studentName + " has been dropped from " + courseName + ".");
            return true;
        } else {
            System.out.println(studentName + " is not registered in " + courseName + ".");
            return false;
        }
    }

    public void displayCourseDetails() {
        System.out.println("Course Name: " + courseName);
        System.out.println("Max Seats: " + maxSeats);
        System.out.println("Registered Students (" + registeredStudents.size() + "): " + registeredStudents);
    }

    public String getCourseName() {
        return courseName;
    }
}